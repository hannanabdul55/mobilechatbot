Run 'python part2.py'

OUTPUT is in file.txt